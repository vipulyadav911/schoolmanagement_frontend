<!DOCTYPE html>
<html lang="en">

<head>
    <!-- metas -->
    <meta charset="utf-8">
    <meta name="author" content="Chitrakoot Web" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="Online Education Learning Template" />
    <meta name="description" content="eLearn - Online Education Learning Template" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- title -->
    <title>eLearn - Online Education Learning Template</title>

    <!-- favicon -->
    <link rel="shortcut icon" href="img/logos/favicon.png" />
    <link rel="apple-touch-icon" href="img/logos/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/apple-touch-icon-114x114.png" />

    <!-- plugins -->
    <link rel="stylesheet" href="css/plugins.css" />
    <link rel="stylesheet" href="css/search.css" />
    <link href="css/styles.css" rel="stylesheet" />
</head>

<body>
    <!-- PAGE LOADING -->
    <div id="preloader">
        <div class="row loader">
            <div class="loader-icon"></div>
        </div>
    </div>

    <!-- COMING SOON -->
    <section class="p-0 bg-img cover-background dark-overlay" data-overlay-dark="6" data-background="img/bg-08.jpg">
        <div class="container d-flex flex-column position-relative z-index-9">
            <div class="row align-items-center min-vh-100 text-center justify-content-center">
                <div class="col-xl-9">
                    <div class="my-1-6">
                        <div class="mb-1-6">
                            <img src="img/logo-inner.png" alt="eLearn Logo - Online Education Learning Platform">
                        </div>
                        <div class="mb-1-6">
                            <h1 class="text-white display-5 font-weight-800">We are coming soon!</h1>
                            <p class="lead font-weight-400 mb-0 text-white">Stay tuned, we are launching very soon...</p>
                        </div>
                        <ul class="countdown d-md-flex justify-content-center align-items-center mb-1-9 mb-md-8 p-0">
                            <li class="text-white"><span class="days">529</span>
                                <p class="timeRefDays text-center">days</p>
                            </li>
                            <li class="text-white"><span class="hours">06</span>
                                <p class="timeRefHours">hours</p>
                            </li>
                            <li class="text-white"><span class="minutes">07</span>
                                <p class="timeRefMinutes">minutes</p>
                            </li>
                            <li class="text-white"><span class="seconds">04</span>
                                <p class="timeRefSeconds">seconds</p>
                            </li>
                        </ul>
                        <div class="row align-items-center text-white">
                            <div class="col-lg-8 mb-1-6 mb-lg-0">
                                <div class="com-contact-info">
                                    <ul>
                                        <li><a href="tel:+442056581823" class="text-white"><i class="fas fa-phone-alt me-1"></i>+44 205-658-1823</a></li>
                                        <li><a href="mailto:info@domain.com" class="text-white"><i class="fas fa-envelope-open-text me-2"></i>info@domain.com</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="social-icons">
                                    <ul>
                                        <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#!"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
 <!-- BUY TEMPLATE
    ================================================== -->
 <div class="buy-theme alt-font d-none d-lg-inline-block"><a href="https://wrapbootstrap.com/theme/elearn-online-education-learning-template-WB0836C05" target="_blank"><i class="fas fa-cart-plus"></i><span>Buy Template</span></a></div>

<div class="all-demo alt-font d-none d-lg-inline-block"><a href="https://www.chitrakootweb.com/contact.php" target="_blank"><i class="far fa-envelope"></i><span>Quick Question?</span></a></div>



<!-- start scroll to top -->
<a href="#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
<!-- end scroll to top -->

<!-- bootstrap -->
<script src="js\bootstrap.min.js.js"></script>

<!-- jQuery -->
<script src="js\jquery.min.js.js"></script>

<!-- popper js -->
<script src="js\popper.min.js.js"></script>

<!-- core.min.js -->
<script src="js\core.min.js.js"></script>

<!-- search -->
<script src="js\search.js.js"></script>

<!-- custom scripts -->
<script src="js\main.js.js"></script>

<!-- form plugins js -->
<script src="js\plugins.js.js"></script>

<!-- form scripts js -->
<script src="js\scripts.js.js"></script>

<!-- all js include end -->

</body>

</html>