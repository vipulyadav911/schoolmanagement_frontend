<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metas -->
    <meta charset="utf-8" />
    <meta name="author" content="Chitrakoot Web" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="Online Education Learning Template" />
    <meta name="description" content="eLearn - Online Education Learning Template" />

    <!-- Title -->
    <title>eLearn - Online Education Learning Template</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.png" />
    <link rel="apple-touch-icon" href="img/logos/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/apple-touch-icon-114x114.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Plugins -->
    <link rel="stylesheet" href="css\plugins.css" />

    <!-- Search CSS -->
    <link rel="stylesheet" href="css\search.css" />

    <!-- Quform CSS -->
    <link rel="stylesheet" href="css\base.css">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="css\styles.css" />
</head>

<body>

    <!-- Page Loading -->
    <div id="preloader"></div>

    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <header class="header-style1 menu_area-light">
            <div class="navbar-default border-bottom border-color-light-white">

                <!-- Start Top Search -->
                <div class="top-search bg-primary">
                    <div class="container">
                        <form class="search-form" action="search.php" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit" aria-label="Search"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off" placeholder="Type & hit enter...">
                                <span class="input-group-addon close-search mt-1" aria-label="Close search"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- End Top Search -->

                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <a href="index.php" class="navbar-brand"><img id="logo" src="img\logo1.jpg" alt="Logo" /></a>
                                    </div>

                                    <div class="navbar-toggler bg-primary"></div>

                                    <!-- Start Menu Area -->
                                    <ul class="navbar-nav ms-auto" id="nav" style="display: none;">
                                        <li><a href="index.php">Home</a></li>
                                        <li>
                                            <a href="#!">Pages</a>
                                            <ul>
                                                <li><a href="about-us.php">About Us</a></li>
                                                <li><a href="instructors.php">Instructors</a></li>
                                                <li><a href="instructors-details.php">Instructors Details</a></li>
                                                <li><a href="pricing.php">Pricing</a></li>
                                                <li><a href="FAQ.php">FAQ</a></li>
                                                <li><a href="404.php">Page 404</a></li>
                                                <li><a href="coming-soon.php">Coming Soon</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#!">Courses</a>
                                            <ul>
                                                <li><a href="courses-grid.php">Courses Grid</a></li>
                                                <li><a href="courses-list.php">Courses List</a></li>
                                                <li><a href="course-details.php">Courses Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#!">Events</a>
                                            <ul>
                                                <li><a href="event-list.php">Event List</a></li>
                                                <li><a href="event-details.php">Event Details</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#!">Portfolio</a>
                                            <ul>
                                                <li><a href="#!">Portfolio Grid</a>
                                                    <ul>
                                                        <li><a href="portfolio-two-columns.php">2 Columns</a></li>
                                                        <li><a href="portfolio.php">3 Columns - Standard</a></li>
                                                        <li><a href="portfolio-four-columns.php">4 Columns</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="portfolio-details.php">Portfolio Details</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#!">Blog</a>
                                            <ul>
                                                <li><a href="blog-grid.php">Blog Grid</a>
                                                    <ul>
                                                        <li><a href="blog-grid-two-columns.php">2 Columns</a></li>
                                                        <li><a href="blog-grid-two-columns-left-sidebar.php">2 Col – Left Sidebar</a></li>
                                                        <li><a href="blog-grid-two-columns-right-sidebar.php">2 Col – Right Sidebar</a></li>
                                                        <li><a href="blog-grid.php">3 Columns - Standard</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="blog-list.php">Blog List</a></li>
                                                <li><a href="blog-details.php">Blog Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                    <!-- End Menu Area -->

                                    <!-- Start Attribute Navigation -->
                                    <div class="attr-nav align-items-xl-center ms-xl-auto main-font">
                                        <ul>
                                            <li class="search"><a href="#!"><i class="fas fa-search" aria-hidden="true"></i></a></li>
                                            <li class="d-none d-xl-inline-block">
                                                <a href="contact.php" class="butn md text-white">
                                                    <i class="fas fa-plus-circle icon-arrow before" aria-hidden="true"></i>
                                                    <span class="label">Apply Now</span>
                                                    <i class="fas fa-plus-circle icon-arrow after" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- End Attribute Navigation -->
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Add your content here -->