 <?php include_once('header.php')?>
 <!-- PAGE TITLE
        ================================================== -->
        <section class="page-title-section bg-img cover-background top-position1 left-overlay-dark" data-overlay-dark="9" data-background="img/bg-04.jpg">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12">
                        <h1>Portfolio Details</h1>
                    </div>
                    <div class="col-md-12">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="#!">Portfolio Details</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- PORTFOLIO DETAILS
        ================================================== -->
        <section>
            <div class="container"> 
                <div class="col-12">
                    <div class="text-center mb-5">
                        <img src="img\portfolio-details-01.jpg" class="primary-shadow border-radius-5" alt="...">
                    </div>
                    <div class="row bg-secondary border-radius-5 mb-1-9 p-1-9">
                        <div class="col-sm-6 col-lg-3 mb-1-9 mb-lg-0">
                            <div class="d-flex">
                                <i class="ti-tag text-white display-18"></i>
                                <div class="ms-3">
                                    <h4 class="mb-1 h5 text-white">Category:</h4>
                                    <span class="text-white opacity9">Other</span>  
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 mb-1-9 mb-lg-0">
                            <div class="d-flex">
                                <i class="ti-user text-white display-18"></i>
                                <div class="ms-3">
                                    <h4 class="mb-1 h5 text-white">Client:</h4>
                                    <span class="text-white opacity9">Casey Solano</span>  
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3 mb-1-9 mb-sm-0">
                            <div class="d-flex">
                                <i class="ti-timer text-white display-18"></i>
                                <div class="ms-3">
                                    <h4 class="mb-1 h5 text-white">Date:</h4>
                                    <span class="text-white opacity9">12, Feb 2023</span>  
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="d-flex">
                                <i class="ti-money text-white display-18"></i>
                                <div class="ms-3">
                                    <h4 class="mb-1 h5 text-white">Cost:</h4>
                                    <span class="text-white opacity9">$225.00</span>  
                                </div>
                            </div>
                        </div>
                    </div>
                    <h3>Project Overview</h3>
                    <p class="mb-1-4">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary</p>
                    <h3>Project Summary</h3>
                    <p class="mb-1-4 w-lg-95">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
                    <div class="row mt-n1-9">
                        <div class="col-lg-6 mt-1-9">
                            <div class="card border-radius-5 h-100 border-color-light-black">
                                <div class="card-body py-4 px-1-9 px-xl-2-6">
                                    <h3 class="h5">Challenges</h3>
                                    <ul class="list-style1 list-unstyled mb-0">
                                        <li>In a free hour, when our force of decision is unhampered.</li>
                                        <li>Certain conditions claims obligation or the commitments.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-1-9">
                            <div class="card border-radius-5 h-100 border-color-light-black">
                                <div class="card-body py-4 px-1-9 px-xl-2-6">
                                    <h3 class="h5">Solutions</h3>
                                    <ul class="list-style1 mb-0 list-unstyled">
                                        <li>Renounced and inconveniences acknowledged.</li>
                                        <li>Force of decision is unrestricted and when nothing.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="page-navigation mt-6">
                    <div class="prev-page">
                        <div class="page-info">
                            <a href="#!">
                                <span class="image-prev"><img src="img\prev-portfolio.jpg" alt="..."></span>
                                <div class="prev-link-page-info">
                                    <h4 class="prev-title">Create Animation</h4>
                                    <span class="date-details"><span class="create-date">March 20, 2023</span></span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="next-page">
                        <div class="page-info">
                            <a href="#!">
                                <div class="next-link-page-info">
                                    <h4 class="next-title">Business Research</h4>
                                    <span class="date-details"><span class="create-date">March 27, 2023</span></span>
                                </div>
                                <span class="image-next"><img src="img\next-portfolio.jpg" alt="..."></span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <?php include_once('footer.php')?>