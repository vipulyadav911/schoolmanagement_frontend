<?php include_once('header.php'); ?>
     <!-- PAGE TITLE
        ================================================== -->
        <section class="page-title-section bg-img cover-background top-position1 left-overlay-dark" data-overlay-dark="9" data-background="img\bg-04.jpg">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12">
                        <h1>Instructors</h1>
                    </div>
                    <div class="col-md-12">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="#!">Instructors</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
  <!-- Instructors
        ================================================== -->
  <section>
      <div class="container">
          <div class="section-heading">
              <span class="sub-title">Instructors</span>
              <h2 class="h1 mb-0">Experience Instructors</h2>
          </div>
          <div class="row">
              <div class="col-lg-4 col-md-6 mb-1-6 mb-md-1-9">
                  <div class="team-style1 text-center">
                      <img src="img\team-01.jpg" class="border-radius-5" alt="...">
                      <div class="team-info">
                          <h3 class="text-primary mb-1 h4">Murilo Souza</h3>
                          <span class="font-weight-600 text-secondary">Web Designer</span>
                      </div>
                      <div class="team-overlay">
                          <div class="d-table h-100 w-100">
                              <div class="d-table-cell align-middle">
                                  <h3><a href="instructors-detaiphp" class="text-white">About Murilo Souza</a></h3>
                                  <p class="text-white mb-0">I preserve each companion certification and I'm an authorized AWS solutions architect professional.</p>
                                  <ul class="social-icon-style1">
                                      <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-linkedin-in"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-md-6 mb-1-6 mb-md-1-9">
                  <div class="team-style1 text-center">
                      <img src="img\team-02.jpg" class="border-radius-5" alt="...">
                      <div class="team-info">
                          <h3 class="text-primary mb-1 h4">Balsam Samira</h3>
                          <span class="font-weight-600 text-secondary">Photographer</span>
                      </div>
                      <div class="team-overlay">
                          <div class="d-table h-100 w-100">
                              <div class="d-table-cell align-middle">
                                  <h3><a href="instructors-details.php" class="text-white">About Balsam Samira</a></h3>
                                  <p class="text-white mb-0">I preserve each companion certification and I'm an authorized AWS solutions architect professional.</p>
                                  <ul class="social-icon-style1">
                                      <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-linkedin-in"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-md-6 mb-1-6 mb-md-1-9">
                  <div class="team-style1 text-center">
                      <img src="img\team-03.jpg" class="border-radius-5" alt="...">
                      <div class="team-info">
                          <h3 class="text-primary mb-1 h4">Rodrigo Ribeiro</h3>
                          <span class="font-weight-600 text-secondary">Psychologist</span>
                      </div>
                      <div class="team-overlay">
                          <div class="d-table h-100 w-100">
                              <div class="d-table-cell align-middle">
                                  <h3><a href="instructors-details.php" class="text-white">About Rodrigo Ribeiro</a></h3>
                                  <p class="text-white mb-0">I preserve each companion certification and I'm an authorized AWS solutions architect professional.</p>
                                  <ul class="social-icon-style1">
                                      <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-linkedin-in"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-md-6 mb-1-6 mb-md-1-9 mb-lg-0">
                  <div class="team-style1 text-center">
                      <img src="img\team-04.jpg" class="border-radius-5" alt="...">
                      <div class="team-info">
                          <h3 class="text-primary mb-1 h4">Melissa Padgett</h3>
                          <span class="font-weight-600 text-secondary">Paraeducator</span>
                      </div>
                      <div class="team-overlay">
                          <div class="d-table h-100 w-100">
                              <div class="d-table-cell align-middle">
                                  <h3><a href="instructors-details.php" class="text-white">About Melissa Padgett</a></h3>
                                  <p class="text-white mb-0">I preserve each companion certification and I'm an authorized AWS solutions architect professional.</p>
                                  <ul class="social-icon-style1">
                                      <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-linkedin-in"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-md-6 mb-1-6 mb-md-0">
                  <div class="team-style1 text-center">
                      <img src="img\team-05.jpg" class="border-radius-5" alt="...">
                      <div class="team-info">
                          <h3 class="text-primary mb-1 h4">Austin Smith</h3>
                          <span class="font-weight-600 text-secondary">Teaching Fellow</span>
                      </div>
                      <div class="team-overlay">
                          <div class="d-table h-100 w-100">
                              <div class="d-table-cell align-middle">
                                  <h3><a href="instructors-details.php" class="text-white">About Austin Smith</a></h3>
                                  <p class="text-white mb-0">I preserve each companion certification and I'm an authorized AWS solutions architect professional.</p>
                                  <ul class="social-icon-style1">
                                      <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-linkedin-in"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 col-md-6">
                  <div class="team-style1 text-center">
                      <img src="img\team-06.jpg" class="border-radius-5" alt="...">
                      <div class="team-info">
                          <h3 class="text-primary mb-1 h4">Leigh Minarik</h3>
                          <span class="font-weight-600 text-secondary">Ballistics Professor</span>
                      </div>
                      <div class="team-overlay">
                          <div class="d-table h-100 w-100">
                              <div class="d-table-cell align-middle">
                                  <h3><a href="instructors-details.php" class="text-white">About Leigh Minarik</a></h3>
                                  <p class="text-white mb-0">I preserve each companion certification and I'm an authorized AWS solutions architect professional.</p>
                                  <ul class="social-icon-style1">
                                      <li><a href="#!"><i class="fab fa-facebook-f"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-twitter"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-youtube"></i></a></li>
                                      <li><a href="#!"><i class="fab fa-linkedin-in"></i></a></li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>

  <!-- FOOTER
        ================================================== -->
        <footer class="bg-dark">
     <div class="container">
         <div class="row">
             <div class="col-md-6 col-lg-3 mb-2-5 mb-lg-0">
                 <a href="index.php" class="footer-logo">
                     <img src="img\logo1.png" class="mb-4" alt="Footer Logo">
                 </a>
                 <p class="mb-1-6 text-white">
                     It's an ideal opportunity to begin investing your energy such that illuminates you.
                 </p>
                 <form class="quform newsletter" action="quform/newsletter-two.php" method="post" enctype="multipart/form-data" onclick="">

                     <div class="quform-elements">

                         <div class="row">

                             <!-- Begin Text input element -->
                             <div class="col-md-12">
                                 <div class="quform-element mb-0">
                                     <div class="quform-input">
                                         <input class="form-control" id="email_address" type="text" name="email_address" placeholder="Subscribe with us">
                                     </div>
                                 </div>
                             </div>
                             <!-- End Text input element -->

                             <!-- Begin Submit button -->
                             <div class="col-md-12">
                                 <div class="quform-submit-inner">
                                     <button class="btn btn-white text-primary m-0 px-2" type="submit"><i class="fas fa-paper-plane"></i></button>
                                 </div>
                                 <div class="quform-loading-wrap text-start"><span class="quform-loading"></span></div>
                             </div>
                             <!-- End Submit button -->

                         </div>

                     </div>

                 </form>
             </div>
             <div class="col-md-6 col-lg-2 mb-2-5 mb-lg-0">
                 <div class="ps-md-1-6 ps-lg-1-9">
                     <h3 class="text-primary h5 mb-2-2">About</h3>
                     <ul class="footer-list">
                         <li><a href="about.php">About Us</a></li>
                         <li><a href="courses-list.php">Courses</a></li>
                         <li><a href="instructors.php">Instructor</a></li>
                         <li><a href="event-list.php">Event</a></li>
                     </ul>
                 </div>
             </div>
             <div class="col-md-6 col-lg-3 mb-2-5 mb-md-0">
                 <div class="ps-lg-1-9 ps-xl-2-5">
                     <h3 class="text-primary h5 mb-2-2">Link</h3>
                     <ul class="footer-list">
                         <li><a href="blog-grid.php">News &amp; Blogs</a></li>
                         <li><a href="portfolio.php">Portfolio</a></li>
                         <li><a href="faq.php">FAQ's</a></li>
                         <li><a href="contact.php">Contact</a></li>
                     </ul>
                 </div>
             </div>
             <div class="col-md-6 col-lg-4">
                 <div class="ps-md-1-9">
                     <h3 class="text-primary h5 mb-2-2">Popular Courses</h3>
                     <div class="media footer-border">
                         <img class="pe-3 border-radius-5" src="img\footer-insta-01.jpg" alt="...">
                         <div class="media-body align-self-center">
                             <h4 class="h6 mb-2"><a href="blog-details.php" class="text-white text-primary-hover">Plan of learning experiences.</a></h4>
                             <span class="text-white small">Mar. 30, 2023</span>
                         </div>
                     </div>
                     <div class="media">
                         <img class="pe-3 border-radius-5" src="img\footer-insta-02.jpg" alt="...">
                         <div class="media-body align-self-center">
                             <h4 class="h6 mb-2"><a href="blog-details.php" class="text-white text-primary-hover">A supportive learning community</a></h4>
                             <span class="text-white small">Mar. 28, 2023</span>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <div class="footer-bar text-center">
             <p class="mb-0 text-white font-weight-500">&copy; <span class="current-year"></span> eLearn Powered by <a href="#!" class="text-secondary">Chitrakoot Web</a></p>
         </div>
     </div>
 </footer>

 </div>

 <!-- BUY TEMPLATE
    ================================================== -->
 <div class="buy-theme alt-font d-none d-lg-inline-block"><a href="https://wrapbootstrap.com/theme/elearn-online-education-learning-template-WB0836C05" target="_blank"><i class="fas fa-cart-plus"></i><span>Buy Template</span></a></div>

 <div class="all-demo alt-font d-none d-lg-inline-block"><a href="https://www.chitrakootweb.com/contact.php" target="_blank"><i class="far fa-envelope"></i><span>Quick Question?</span></a></div>

 

 <!-- start scroll to top -->
 <a href="#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
 <!-- end scroll to top -->

 <!-- bootstrap -->
 <script src="js\bootstrap.min.js.js"></script>

 <!-- jQuery -->
 <script src="js\jquery.min.js.js"></script>

 <!-- popper js -->
 <script src="js\popper.min.js.js"></script>

 <!-- core.min.js -->
 <script src="js\core.min.js.js"></script>

 <!-- search -->
 <script src="js\search.js.js"></script>

 <!-- custom scripts -->
 <script src="js\main.js.js"></script>

 <!-- form plugins js -->
 <script src="js\plugins.js.js"></script>

 <!-- form scripts js -->
 <script src="js\scripts.js.js"></script>

 <!-- all js include end -->

 </body>

 </html>