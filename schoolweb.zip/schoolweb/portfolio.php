  <?php include_once('header.php')?>
  <!-- PAGE TITLE
        ================================================== -->
        <section class="page-title-section bg-img cover-background top-position1 left-overlay-dark" data-overlay-dark="9" data-background="img/bg-04.jpg">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12">
                        <h1>Portfolio Standard</h1>
                    </div>
                    <div class="col-md-12">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="#!">Portfolio Standard</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- PORTFOLIO 3 COLUMNS
        ================================================== -->
        <section>
            <div class="container">
                <div class="section-heading">
                    <span class="sub-title">Discover New</span>
                    <h2 class="h1 mb-0">Our Portfolio</h2>
                </div>
                <div class="row mt-n1-9 portfolio-gallery">
                    <div class="col-md-6 col-xl-4 mt-1-9" data-src="img\portfolio-01.jpg" data-sub-html="<h4 class='text-white'>Design & Typography</h4>">
                        <div class="portfolio-wrapper">
                            <img class="border-radius-5" src="img\portfolio-01.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-content">
                                    <a class="popimg me-2" href="#!"><i class="ti-zoom-in"></i></a>
                                    <a href="portfolio-details.php" class="portfolio-link"><i class="ti-link"></i></a>
                                    <h4 class="mb-0 text-white">Design & Typography</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4 mt-1-9" data-src="img\portfolio-02.jpg" data-sub-html="<h4 class='text-white'>Business Research</h4>">
                        <div class="portfolio-wrapper">
                            <img class="border-radius-5" src="img\portfolio-02.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-content">
                                    <a class="popimg me-2" href="img\portfolio-02.jpg"><i class="ti-zoom-in"></i></a>
                                    <a href="portfolio-details.php" class="portfolio-link"><i class="ti-link"></i></a>
                                    <h4 class="mb-0 text-white">Business Research</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4 mt-1-9" data-src="img\portfolio-03.jpg" data-sub-html="<h4 class='text-white'>Software Development</h4>">
                        <div class="portfolio-wrapper">
                            <img class="border-radius-5" src="img\portfolio-03.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-content">
                                    <a class="popimg me-2" href="img\portfolio-03.jpg"><i class="ti-zoom-in"></i></a>
                                    <a href="portfolio-details.php" class="portfolio-link"><i class="ti-link"></i></a>
                                    <h4 class="mb-0 text-white">Software Development</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4 mt-1-9" data-src="img\portfolio-04.jpg" data-sub-html="<h4 class='text-white'>Graphic Design</h4>">
                        <div class="portfolio-wrapper">
                            <img class="border-radius-5" src="img\portfolio-04.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-content">
                                    <a class="popimg me-2" href="img\portfolio-04.jpg"><i class="ti-zoom-in"></i></a>
                                    <a href="portfolio-details.php" class="portfolio-link"><i class="ti-link"></i></a>
                                    <h4 class="mb-0 text-white">Graphic Design</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4 mt-1-9" data-src="img\portfolio-05.jpg" data-sub-html="<h4 class='text-white'>Learning Languages</h4>">
                        <div class="portfolio-wrapper">
                            <img class="border-radius-5" src="img\portfolio-05.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-content">
                                    <a class="popimg me-2" href="img\portfolio-05.jpg"><i class="ti-zoom-in"></i></a>
                                    <a href="portfolio-details.php" class="portfolio-link"><i class="ti-link"></i></a>
                                    <h4 class="mb-0 text-white">Learning Languages</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-4 mt-1-9" data-src="img\portfolio-06.jpg" data-sub-html="<h4 class='text-white'>Create Animation</h4>">
                        <div class="portfolio-wrapper">
                            <img class="border-radius-5" src="img\portfolio-06.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-content">
                                    <a class="popimg me-2" href="img\portfolio-06.jpg"><i class="ti-zoom-in"></i></a>
                                    <a href="portfolio-details.php" class="portfolio-link"><i class="ti-link"></i></a>
                                    <h4 class="mb-0 text-white">Create Animation</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php include_once('footer.php')?>